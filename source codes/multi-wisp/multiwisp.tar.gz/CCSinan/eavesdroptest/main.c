#include "wisp-base.h"
#define BSL_VIRTUAL_ID   0x1900
#define BSL_ID           0x1910
#define BSL_PASSWD       0x1920
#define BOOT_READY		 0x1930


WISP_dataStructInterface_t wispData;

/**
 * This function is called by WISP FW after a successful ACK reply
 *
 */
void my_ackCallback (void) {
	asm(" NOP");
}

/**
 * This function is called by WISP FW after a successful read command
 *  reception
 *
 */
void my_readCallback (void) {
	wispData.readBufPtr[1] =(TB0R)&0xFF;
	wispData.readBufPtr[0] = (TB0R>>8)&0xFF;
}

/**
 * This function is called by WISP FW after a successful write command
 *  reception
 *
 */
void my_writeCallback (void) {
	asm(" NOP");
}

/**
 * This function is hidden within the process time of the wisp BEFORE responding to the reader!
 * While the maximum delayed response time is 20 ms, the WISP lives for ~14 ms per power cycle.
 * Furthermore, the bigger this function is, the smaller the time window becomes (i.e. less bwr/sec).
 */
void my_blockWriteCallback  (void) {
	uint16_t cmd = wispData.blockWriteBufPtr[0];
	uint16_t cmd2 = wispData.blockWriteBufPtr[31];
	if(cmd == cmd2){
		if (cmd == 0xFF){
			BITSET(PLED1OUT,PIN_LED1);
		}
		else if(cmd == 0xF0){
			BITCLR(PLED1OUT,PIN_LED1);
		}

	}
}
/**
 * This implements the user application and should never return
 *
 * Must call WISP_init() in the first line of main()
 * Must call WISP_doRFID() at some point to start interacting with a reader
 */

void main(void) {
	WISP_init();

	// Register callback functions with WISP comm routines
	//WISP_registerCallback_ACK(&my_ackCallback);
	//WISP_registerCallback_READ(&my_readCallback); // method 1 needs this
	//WISP_registerCallback_WRITE(&my_writeCallback);
	WISP_registerCallback_BLOCKWRITE(&my_blockWriteCallback); //method 2 needs this
	rfid.isEavesDropping = 1;
	// Initialize BlockWrite buffer.
	uint16_t bwr_array[32] = {0};
	RWData.bwrBufPtr = bwr_array;

	// Get access to EPC, READ, and WRITE data buffers
	WISP_getDataBuffers(&wispData);

	// Set up operating parameters for WISP comm routines
	WISP_setMode( MODE_READ | MODE_WRITE | MODE_USES_SEL);
	//WISP_setAbortConditions(CMD_ID_READ | CMD_ID_WRITE /*| CMD_ID_BLOCKWRITE*/ ); // this abort check is disabled in assembly.

	(* (uint16_t *) (BSL_ID)) = 0x0304;
	// Set up EPC
	wispData.epcBuf[0] = ((* (uint16_t *) (BSL_ID))>> 8)& 0xFF; 			// WISP ID
	wispData.epcBuf[1] = (* (uint16_t *) (BSL_ID))  & 0xFF; 	// WISP ID
	wispData.epcBuf[2] = 0xea; // Header
	wispData.epcBuf[3] = 0xe5; // Header
	wispData.epcBuf[4] = 0xd3; // Address
	wispData.epcBuf[5] = 0x09; // Address
	wispData.epcBuf[6] = 0xe3; // Checksum
	/*wispData.epcBuf[7] = 0x00;
	wispData.epcBuf[8] = 0x00;
	wispData.epcBuf[9] = 0x00; // RFID Status/Control
	wispData.epcBuf[10]= 0x00; // RFID Status/Control
	wispData.epcBuf[11]= 0x00;*/

	// Talk to the RFID reader.
	while (FOREVER) {
		WISP_doRFID();
	}
}

