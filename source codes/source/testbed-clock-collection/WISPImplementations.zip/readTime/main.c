#include "wisp-base.h"


WISP_dataStructInterface_t wispData;

/**
 * This function is called by WISP FW after a successful ACK reply
 *
 */
void my_ackCallback (void) {
	asm(" NOP");
}

/**
 * This function is called by WISP FW after a successful read command
 *  reception
 *
 */
void my_readCallback (void) {
	wispData.readBufPtr[1] =(TB0R)&0xFF;
	wispData.readBufPtr[0] = (TB0R>>8)&0xFF;
}

/**
 * This function is called by WISP FW after a successful write command
 *  reception
 *
 */
void my_writeCallback (void) {
	asm(" NOP");
}

/**
 * This function is hidden within the process time of the wisp BEFORE responding to the reader!
 * While the maximum delayed response time is 20 ms, the WISP lives for ~14 ms per power cycle.
 * Furthermore, the bigger this function is, the smaller the time window becomes (i.e. less bwr/sec).
 */
void my_blockWriteCallback  (void) {
	uint16_t cmd = wispData.blockWriteBufPtr[0];
	uint16_t cmd2 = wispData.blockWriteBufPtr[31];
	if(cmd == cmd2){
		uint16_t in = (cmd-1)*2;
		wispData.readBufPtr[in+1] =(TB0R)&0xFF;
		wispData.readBufPtr[in] = (TB0R>>8)&0xFF;
	}
}
/**
 * This implements the user application and should never return
 *
 * Must call WISP_init() in the first line of main()
 * Must call WISP_doRFID() at some point to start interacting with a reader
 */

void main(void) {
	WISP_init();

	// configure timer B
	TB0CTL = TBSSEL_1 | CNTL_0 | MC__CONTINUOUS | TBCLR; // select ACLK, 16-bit, counting up, clear timer
	//TB0EX0 = TBIDEX_7 // divide by 8

	// Register callback functions with WISP comm routines
	//WISP_registerCallback_ACK(&my_ackCallback);
	//WISP_registerCallback_READ(&my_readCallback); // CHANGE: method 1 needs this
	//WISP_registerCallback_WRITE(&my_writeCallback);
	WISP_registerCallback_BLOCKWRITE(&my_blockWriteCallback); //CHANGE:  method 2 needs this
	// Initialize BlockWrite buffer.
	uint16_t bwr_array[32] = {0};
	RWData.bwrBufPtr = bwr_array;

	// Get access to EPC, READ, and WRITE data buffers
	WISP_getDataBuffers(&wispData);

	// Set up operating parameters for WISP comm routines
	WISP_setMode( MODE_READ | MODE_WRITE | MODE_USES_SEL);
	//WISP_setAbortConditions(CMD_ID_READ | CMD_ID_WRITE /*| CMD_ID_BLOCKWRITE*/ ); // this abort check is disabled in assembly.

	uint16_t ID = 0x0273;
	// Set up EPC
	wispData.epcBuf[0] = (ID>> 8)& 0xFF; 			// WISP ID
	wispData.epcBuf[1] = ID  & 0xFF; 	// WISP ID
	wispData.epcBuf[2] = 0xc1; // random epc: cl0creader
	wispData.epcBuf[3] = 0x0c;
	wispData.epcBuf[4] = 0x3e;
	wispData.epcBuf[5] = 0xad;
	wispData.epcBuf[6] = 0xe3;
	/*wispData.epcBuf[7] = 0x00;
	wispData.epcBuf[8] = 0x00;
	wispData.epcBuf[9] = 0x00; // RFID Status/Control
	wispData.epcBuf[10]= 0x00; // RFID Status/Control
	wispData.epcBuf[11]= 0x00;*/

	// Talk to the RFID reader.
	while (FOREVER) {
		WISP_doRFID();
		BITSET(PLED1OUT,PIN_LED1);
		BITSET(PLED2OUT,PIN_LED2);
	}
}

